#Word Generation Using API

# Points Covered

Implemented using node.js

* All of the word formations are returned
* Cache have been implemented using memory-cache library with Time to Live(TTL) of 1 minute so that new searches were not done again and again
* Endpoint is exactly he same menioned in problem statement

## Installing files

npm install-> on terminal

## Starting Application

node index-> on terminal